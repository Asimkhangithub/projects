document.addEventListener("DOMContentLoaded", function () {
    let slides = document.querySelectorAll(".testimonial-slide");
    let currentSlide = 0;

    function showNextSlide() {
        slides[currentSlide].classList.remove("active");
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add("active");
    }

    setInterval(showNextSlide, 3000); // Change slide every 3 seconds
});

document.addEventListener("DOMContentLoaded", function () {
    let slides = document.querySelectorAll(".review-slide");
    let index = 0;

    function showNextSlide() {
        slides[index].style.display = "none"; // Hide current slide
        index = (index + 1) % slides.length; // Move to next slide
        slides[index].style.display = "block"; // Show new slide
    }

    setInterval(showNextSlide, 3000); // Auto-slide every 3 seconds
});

 // for pop message //

// Wait for the DOM to load before executing script
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("contactForm").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevents page refresh

        // Show the popup message
        document.getElementById("popupMessage").style.display = "flex";
    });
});

// Function to close the popup
function closePopup() {
    document.getElementById("popupMessage").style.display = "none";
}
